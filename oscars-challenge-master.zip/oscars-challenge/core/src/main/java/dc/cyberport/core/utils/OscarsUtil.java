package dc.cyberport.core.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class OscarsUtil {
	
	  //TODO: remove this method once your check is finished
    public static JSONArray printEntries(SlingHttpServletRequest req) throws JSONException {
    	
    	JSONArray jsonArray= new JSONArray();
    	
        final Resource resource = req.getResource();
        for (Resource child : resource.getChildren()) {
        	JSONObject filmEntry = new JSONObject(child.getValueMap());
        	jsonArray.put(filmEntry);
        }
        
        
        JSONArray sortedJsonArray = new JSONArray();

        JSONArray filterdArray = filterData(jsonArray, req);
        
        List<JSONObject> jsonValues = new ArrayList<JSONObject>();
        for (int i = 0; i < filterdArray.length(); i++) {
            jsonValues.add(filterdArray.getJSONObject(i));
        }
        if(filterdArray.length() > 0){
        Collections.sort( jsonValues, new Comparator<JSONObject>() {
            @Override
            public int compare(JSONObject a, JSONObject b) {
                String valA = new String();
                String valB = new String();

                try {
                	for (Entry<String, String[]> entry : req.getParameterMap().entrySet()) {
                	    	if("sortBy".equals(entry.getKey())){
                	    		valA = (String) a.get(entry.getValue()[0]);
                                valB = (String) b.get(entry.getValue()[0]);
                	    	}else{
                	    		valA = (String) a.get("title");
                                valB = (String) b.get("title");
                	    	}
                	}
                } 
                catch (JSONException e) {
                    //do something
                }

                return valA.compareTo(valB);
                //if you want to change the sort order, simply use the following:
                //return -valA.compareTo(valB);
            }
        });

	        for (int i = 0; i < filterdArray.length(); i++) {
	            sortedJsonArray.put(jsonValues.get(i));
	        }
        }
     System.out.println("final array:::::::"+sortedJsonArray);
      	return sortedJsonArray;
      
    }
    
    private static JSONArray filterData(JSONArray jsonArray, SlingHttpServletRequest req) throws JSONException{
    	  JSONArray filterdArray = new JSONArray();
    	  int limit = 0;
    	  
    	  for(int obj=0; obj < jsonArray.length(); obj++){
    		  JSONObject filmObj= jsonArray.getJSONObject(obj);
	    	  boolean paramsExist = true;
	    	  for (Entry<String, String[]> entry : req.getParameterMap().entrySet()) {
	    		  limit = entry.getKey().equals("limit") ? Integer.parseInt(entry.getValue()[0]) : 0;
	  	    		if((entry.getKey().equals("minAwards") && Integer.parseInt(filmObj.get("awards").toString()) < Integer.parseInt(entry.getValue()[0]))
	  	    			|| (entry.getKey().equals("maxAwards") && Integer.parseInt(filmObj.get("awards").toString()) > Integer.parseInt(entry.getValue()[0]))
	  	    		    || (entry.getKey().equals("minYear") && Integer.parseInt(filmObj.get("year").toString()) < Integer.parseInt(entry.getValue()[0]))
	  	    			|| (entry.getKey().equals("maxYear") && Integer.parseInt(filmObj.get("year").toString()) > Integer.parseInt(entry.getValue()[0]))
	  	    		   ){
	  	    		    paramsExist = false;
	  	    		}else if(filmObj.has(entry.getKey()) && entry.getKey().equals("isBestPicture")
	  	    				&& Boolean.parseBoolean(entry.getKey().toString()) != Boolean.parseBoolean(filmObj.get("isBestPicture").toString())){
	  	    			paramsExist = false;
	  	    		}else if(filmObj.has(entry.getKey()) && entry.getKey().equals("title")
	  	    				&& filmObj.get("title").toString().equals(entry.getValue()[0])){
	  	    			paramsExist = false;
	  	    		}else if(filmObj.has(entry.getKey()) && !entry.getKey().equals("title") && !entry.getKey().equals("isBestPicture") &&
	  	    				Integer.parseInt(filmObj.get(entry.getKey()).toString()) != Integer.parseInt(entry.getValue()[0])){
		  	    			paramsExist = false;
		  	    	}
	  	    		
	  	    	 }
	    	     
	    	  if(paramsExist){
	    		  filmObj.remove("sling:resourceType");
	    		  filmObj.remove("jcr:primaryType");
	    		  if(limit > 0 && filterdArray.length() >= limit){
	    			  filterdArray.put(filmObj);
	    			  break;
			      }else{
			    	  filterdArray.put(filmObj);
			      }
	    	  }
	    	 
    	  }
		return filterdArray;
    }

}

class JSONComparator implements Comparator<JSONObject> {

@Override
public int compare(JSONObject o1, JSONObject o2) {
    String v1;
	try {
		v1 = (String) ((JSONObject) o1.get("attributes")).get("COMMERCIALNAME_E");
	
    String v3 = (String) ((JSONObject) o2.get("attributes")).get("COMMERCIALNAME_E");
    return v1.compareTo(v3);
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return 0;
}

}